---
name: Feature Request
about: Suggest ideas, changes or other enhancements for the library
title: ''
labels: enhancement
assignees: ''

---

Please describe your idea. Would you like another friendly method? Renaming them to something more appropriated? Changing the way something works?
